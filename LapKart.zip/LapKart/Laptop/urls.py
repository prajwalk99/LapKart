from django.urls import path
from . import views


urlpatterns = [
    path('test/',views.test_view),
    path('show/',views.show_laptop),
    path('add/',views.add_laptop),
    path('layout/',views.layout_laptop),
    path('delete/<i>/',views.delete_laptop),
    path('update/<i>/',views.update_laptop),
]