from django.db import models

class Laptop(models.Model):
    company = models.CharField(max_length=32)
    variant = models.CharField(max_length=32)
    processor = models.CharField(max_length=32)
    ram = models.IntegerField()
    rom = models.FloatField()
