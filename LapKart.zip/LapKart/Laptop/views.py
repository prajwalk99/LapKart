from django.http import HttpResponse
from django.shortcuts import render, redirect
from .models import Laptop
from .forms import LaptopModelForm
from django.contrib.auth.decorators import login_required
from django.views.decorators.cache import never_cache
# Create your views here.


def layout_laptop(request):
    template_name = "Laptop/layout.html"
    context = {}
    return render(request, template_name, context)
def test_view(request):
    template_name= "Laptop/layout.html"
    context={}
    return render(request,template_name,context)

@never_cache
@login_required
def show_laptop(request):
    lap = Laptop.objects.all()
    template_name = "Laptop/show_laptop.html"
    context = {"lap":lap}
    return render(request, template_name, context)

@never_cache
@login_required
def add_laptop(request):
    form = LaptopModelForm()
    if request.method == "POST":
        form = LaptopModelForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("/laptop/show/")

    template_name = "Laptop/add_laptop.html"
    context = {"form":form}
    return render(request, template_name, context)

@never_cache
@login_required
def delete_laptop(request,i):
    lap_obj=Laptop.objects.get(id=i)
    lap_obj.delete()
    return redirect('/laptop/show/')

@never_cache
@login_required
def update_laptop(request,i):
    lap_obj= Laptop.objects.get(id=i)
    form = LaptopModelForm(instance=lap_obj)
    if request.method == "POST":
        form = LaptopModelForm(request.POST,instance=lap_obj)
        if form.is_valid():
            form.save()
            return redirect("/laptop/show/")

    template_name = "Laptop/add_laptop.html"
    context = {"form":form}
    return render(request, template_name, context)